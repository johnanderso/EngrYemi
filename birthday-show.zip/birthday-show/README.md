# A Day in Your Honour, Sir

An interactive birthday show for Engr. Yemi.

## Put it online with GitHub Pages
1. Create a new repository on GitHub (set it to Public).
2. Click "uploading an existing file" and drag in everything from this folder: `index.html`, `README.md` and the whole `assets` folder (keep the folder structure).
3. Commit the changes.
4. Go to Settings, then Pages. Under "Build and deployment", choose "Deploy from a branch", pick `main` and `/ (root)`, then Save.
5. After a minute or two your link will appear at the top of the Pages screen: `https://YOUR-USERNAME.github.io/REPO-NAME/`

## Edit the details
Open `index.html` and look for the `CONFIG` block near the bottom: title, name, message and video path.
